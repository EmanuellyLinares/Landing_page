
import Header from "./components/Header";
import "./App.css";

function App() {
    return (
        <div className="home">
            <Header />

            <main className="main">
                <div className="col col1">
                    <h2>Seus filmes</h2>

                    <p>
                        Descubra filmes incríveis e encontre sua próxima
                        história favorita.
                    </p>

                    <button type="button">
                        Explorar filmes
                    </button>
                </div>

                <div className="col cards">
                    <div className="card card1"></div>
                    <div className="card card2"></div>
                    <div className="card card3"></div>
                    <div className="card card4"></div>
                    <div className="card card5"></div>
                    <div className="card card6"></div>
                </div>
            </main>
        </div>
    );
}

export default App;